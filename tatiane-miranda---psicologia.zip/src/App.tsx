import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { WhatsAppButton } from './components/WhatsAppButton';
import { CustomCursor } from './components/CustomCursor';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="relative min-h-screen">
      <CustomCursor />
      <Navbar />
      
      <main>
        <Hero />
        
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <About />
        </motion.div>

        <Services />
        
        <Testimonials />
        
        <Contact />
      </main>

      <footer className="py-12 bg-primary text-white/60">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <h3 className="text-white font-serif text-2xl mb-2">Tatiane Miranda</h3>
            <p className="text-sm font-light">Psicóloga Clínica • CRP 06/00000</p>
          </div>
          
          <div className="flex space-x-8 text-sm font-light">
            <a href="#home" className="hover:text-white transition-colors">Início</a>
            <a href="#about" className="hover:text-white transition-colors">Sobre</a>
            <a href="#services" className="hover:text-white transition-colors">Serviços</a>
            <a href="#contact" className="hover:text-white transition-colors">Contato</a>
          </div>

          <div className="text-center md:text-right text-xs font-light">
            <p>© 2024 Tatiane Miranda. Todos os direitos reservados.</p>
            <p className="mt-1">Desenvolvido com cuidado.</p>
          </div>
        </div>
      </footer>

      <WhatsAppButton />
    </div>
  );
}
